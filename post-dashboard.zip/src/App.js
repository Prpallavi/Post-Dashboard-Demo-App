import logo from './logo.svg';
import './App.css';
import PostDashboard from './features/posts/postDashboard';

function App() {
  return <PostDashboard />
}

export default App;
