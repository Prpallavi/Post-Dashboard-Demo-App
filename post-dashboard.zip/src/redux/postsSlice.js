import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import {
  fetchPostsAPI,
  createPostAPI,
  updatePostAPI,
  deletePostAPI
} from '../services/postsAPI'

export const fetchPosts = createAsyncThunk('posts/fetchPosts', async () => {
  const response = await fetchPostsAPI()
  return response.data.slice(0, 5)
})

export const addPost = createAsyncThunk('posts/addPost', async (post) => {
  const response = await createPostAPI(post)
  return response.data
})

export const editPost = createAsyncThunk('posts/editPost', async (post) => {
  const response = await updatePostAPI(post)
  return response.data
})

export const removePost = createAsyncThunk('posts/removePost', async (id) => {
  await deletePostAPI(id)
  return id
})

const postsSlice = createSlice({
  name: 'posts',
  initialState: {
    items: [],
    status: 'idle'
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPosts.pending, (state) => {
        state.status = 'loading'
      })
      .addCase(fetchPosts.fulfilled, (state, action) => {
        state.status = 'succeeded'
        state.items = action.payload
      })
      .addCase(addPost.fulfilled, (state, action) => {
        state.items.unshift(action.payload)
      })
      .addCase(editPost.fulfilled, (state, action) => {
        const index = state.items.findIndex(p => p.id === action.payload.id)
        if (index !== -1) state.items[index] = action.payload
      })
      .addCase(removePost.fulfilled, (state, action) => {
        state.items = state.items.filter(p => p.id !== action.payload)
      })
  }
})

export default postsSlice.reducer