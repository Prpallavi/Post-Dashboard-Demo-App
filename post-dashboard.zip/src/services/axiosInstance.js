import axios from "axios";

const BASE_URL = process.env.REACT_APP_BASE_URL;

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 5000,
});


// REQUEST INTERCEPTOR
axiosInstance.interceptors.request.use(
  (config) => {
    // example: attach token automatically
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    console.log("Request sent:", config);
    return config;
  },
  (error) => Promise.reject(error)
);


// RESPONSE INTERCEPTOR
axiosInstance.interceptors.response.use(
  (response) => {
    // successful response
    return response;
  },
  (error) => {
    if (error.response) {
      const message = error.response.data?.message || "Server error";

      // example: auto logout if unauthorized
      if (error.response.status === 401) {
        localStorage.removeItem("token");
        window.location.href = "/login";
      }

      return Promise.reject(new Error(message));
    }

    if (error.request) {
      return Promise.reject(new Error("No response from server"));
    }

    return Promise.reject(new Error(error.message));
  }
);

export default axiosInstance;