// import axios from "axios";

// const BASE_URL = process.env.REACT_APP_BASE_URL;

// // common error handler
// const handleError = (error) => {
//   if (error.response) {
//     // server responded with error status
//     throw new Error(error.response.data?.message || "Server error");
//   } else if (error.request) {
//     // request sent but no response
//     throw new Error("No response from server");
//   } else {
//     // something else
//     throw new Error(error.message);
//   }
// };

// export const fetchPostsAPI = async () => {
//   try {
//     return await axios.get(`${BASE_URL}/posts`,{timeout:5000});
//   } catch (error) {
//     handleError(error);
//   }
// };

// export const createPostAPI = async (post) => {
//   try {
//     return await axios.post(`${BASE_URL}/posts`, post);
//   } catch (error) {
//     handleError(error);
//   }
// };

// export const updatePostAPI = async (post) => {
//   try {
//     return await axios.put(`${BASE_URL}/posts/${post.id}`, post);
//   } catch (error) {
//     handleError(error);
//   }
// };

// export const deletePostAPI = async (id) => {
//   try {
//     return await axios.delete(`${BASE_URL}/posts/${id}`);
//   } catch (error) {
//     handleError(error);
//   }
// };

import axiosInstance from "./axiosInstance";

export const fetchPostsAPI = () => {
  return axiosInstance.get("/posts");//https://jsonplaceholder.typicode.com/posts
};

export const createPostAPI = (post) => {
  return axiosInstance.post("/posts", post);
};

export const updatePostAPI = (post) => {
  return axiosInstance.put(`/posts/${post.id}`, post);
};

export const deletePostAPI = (id) => {
  return axiosInstance.delete(`/posts/${id}`);
};