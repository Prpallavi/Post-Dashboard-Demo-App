import { useDispatch } from 'react-redux'
import { Card, CardContent, Typography, Button } from '@mui/material'
import { removePost } from '../../redux/postsSlice'

export default function PostItem({ post }) {
  const dispatch = useDispatch()

  return (
    <Card sx={{ mb: 2 }}>
      <CardContent>
        <Typography variant="h6">{post.title}</Typography>
        <Typography>{post.body}</Typography>
        <Button
          color="error"
          onClick={() => dispatch(removePost(post.id))}
        >
          Delete
        </Button>
      </CardContent>
    </Card>
  )
}
