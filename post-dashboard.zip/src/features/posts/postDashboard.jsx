import { Box, Container, Typography, Card, CardContent } from '@mui/material'
import PostForm from './postForm'
import PostList from './postList'

export default function PostDashboard() {
  return (
    <Box sx={{ display: 'flex', height: '100vh',   // lock screen height
    overflow: 'hidden' }}>
      
      {/* LEFT SIDE - APP INFO */}
      <Box
  sx={{
    flex: 1,
    display: { xs: 'none', md: 'flex' },
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    textAlign: 'center',
    px: 5,
    color: 'white',
    background: '#513370',
    borderTopRightRadius: '120px',
    borderBottomRightRadius: '120px',
  }}
>
        <Typography variant="h3" fontWeight="bold" gutterBottom>
          My Post App
        </Typography>

        <Typography variant="h6" sx={{ maxWidth: 400, opacity: 0.9 }}>
          Create, manage and explore posts in one place. 
          Share your thoughts, organize content, and stay connected.
        </Typography>
      </Box>

      
      {/* RIGHT SIDE - DASHBOARD */}
      <Box
  sx={{
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    bgcolor: '#fcfdff',
    p: 3,
    height: '93vh',        // full screen
    overflow: 'hidden',     // prevent page scroll
  }}
>
  <Container maxWidth="md" sx={{ height: '100%' }}>
    
    <Card
      sx={{
        boxShadow: 4,
        borderRadius: 3,
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      
      {/* HEADER FIXED */}
      <CardContent sx={{ pb: 0 }}>
        <Typography variant="h4" sx={{ mb: 3 }}>
          Create Posts 
        </Typography>
      </CardContent>

       <CardContent
        
      >
        <PostForm />
      
      </CardContent>
        
            {/* SCROLL AREA */}
      <CardContent
        sx={{
          flex: 1,
          overflowY: 'auto',
        }}
      >
       
        <PostList />
      </CardContent>
    </Card>


  </Container>
</Box>

    </Box>
  )
}