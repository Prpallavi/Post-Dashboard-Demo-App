import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { TextField, Button, Box } from '@mui/material'
import { addPost } from '../../redux/postsSlice'

export default function PostForm() {
  const dispatch = useDispatch()
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    dispatch(addPost({ title, body }))
    setTitle('')
    setBody('')
  }

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mb: 3 }}>
      <TextField
        label="Title"
        fullWidth
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        sx={{ mb: 2 }}
      />
      <TextField
        label="Body"
        fullWidth
        value={body}
        onChange={(e) => setBody(e.target.value)}
        sx={{ mb: 2 }}
      />
      <Button variant="contained" type="submit">Add Post</Button>
    </Box>
  )
}
