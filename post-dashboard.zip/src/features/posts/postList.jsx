import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'

import PostItem from './postItem'
import { fetchPosts } from '../../redux/postsSlice'

export default function PostList() {
  const dispatch = useDispatch()
  const { items, status } = useSelector(state => state.posts)

  useEffect(() => {
    if (status === 'idle') dispatch(fetchPosts())
  }, [status, dispatch])

  if (status === 'loading') return <p>Loading...</p>

  return items.map(post => <PostItem key={post.id} post={post} />)
}
