Task 1:

1. Run the project
2. Open console
3. Type in input field
4. Observe slow UI
5. Optimize it

Explanation:
task1 - Prevent slowCalculation from running when only the input field changes.

task2 - Prevent child re-render when parent state updates.

task3 - Prevent Box from re-rendering on every button click.

task4 - Prevent repeated API calls.

task5 - Improve rendering performance and stability.
