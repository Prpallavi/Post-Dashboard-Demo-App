import React, { useState } from 'react';
export function List({ items }) {
  return (
    <>
      {items?.map((item, index) => (
        <div key={index}>{item.name}</div>
      ))}
    </>
  );
}
