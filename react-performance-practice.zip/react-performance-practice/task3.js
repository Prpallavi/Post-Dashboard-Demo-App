import React, { useState } from 'react';
const Box = React.memo(({ style }) => {
  console.log('Box rendered');
  return <div style={style}>Styled Box</div>;
});

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <>
      <button onClick={() => setCount(count + 1)}>Increment</button>
      <Box style={{ background: 'red', padding: 20 }} />
    </>
  );
}
