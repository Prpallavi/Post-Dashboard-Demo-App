import React, { useEffect, useState } from "react";

export default function DataFetcher() {
  const [data, setData] = useState(null);

  useEffect(() => {
    console.log("Fetching data...");
    fetch("/api/data")
      .then((res) => res.json())
      .then(setData);
  });

  return <div>{data ? "Loaded" : "Loading..."}</div>;
}