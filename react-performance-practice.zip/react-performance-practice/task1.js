import React, { useState } from 'react';

function ExpensiveComponent() {
  const [count, setCount] = useState(0);
  const [text, setText] = useState('');

  function slowCalculation(num) {
    console.log('Calculating...');
    for (let i = 0; i < 1000000000; i++) {} // heavy work
    return num * 2;
  }

  const result = slowCalculation(count);

  return (
    <div>
      <h2>Result: {result}</h2>

      <button onClick={() => setCount(count + 1)}>Increment</button>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Typing triggers re-render"
      />
    </div>
  );
}

export default ExpensiveComponent;
